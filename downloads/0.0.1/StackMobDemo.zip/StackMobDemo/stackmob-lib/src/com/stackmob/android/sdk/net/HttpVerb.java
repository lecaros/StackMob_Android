package com.stackmob.android.sdk.net;

public enum HttpVerb {
  GET, POST, PUT, DELETE
}
